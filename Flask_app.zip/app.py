import os
from flask import Flask, render_template, request, send_file, flash
import pandas as pd
import numpy as np
import tensorflow as tf
import joblib
from datetime import datetime
import io

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Required for flash messages

# Load model and preprocessor at startup
model = tf.keras.models.load_model("model_no_svd_clean.keras")
preprocessor = joblib.load("preprocessor.pkl")

def rating_emoji(rating):
    """Helper function to get emoji based on predicted rating"""
    if rating >= 4.5:
        return "🥰"
    elif rating >= 3.5:
        return "🙂"
    elif rating >= 2.5:
        return "😐"
    elif rating >= 1.5:
        return "😕"
    else:
        return "😞"

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get form data
        review_title = request.form.get('review_title', '')
        review_text = request.form.get('review_text', '')
        skin_tone = request.form.get('skin_tone')
        skin_type = request.form.get('skin_type')

        # Validate input
        if not review_title.strip() and not review_text.strip():
            flash('Please enter a review title or review text.', 'error')
            return render_template('index.html')

        # Prepare input data
        full_review = f"{review_title} {review_text}".strip()
        input_df = pd.DataFrame([{
            "full_review": full_review,
            "skin_tone_grouped": skin_tone,
            "skin_type": skin_type,
            "is_recommended": "unknown"
        }])

        # Transform input and make prediction
        X_input_transformed = preprocessor.transform(input_df)
        X_tensor = tf.convert_to_tensor(X_input_transformed.toarray(), dtype=tf.float32)
        pred = model.predict(X_tensor).flatten()[0]
        pred = max(1.0, min(5.0, pred))
        pred_rounded = round(pred * 2) / 2
        emoji = rating_emoji(pred_rounded)
        recommended = "Yes" if pred_rounded >= 3.0 else "No"

        # Log prediction
        with open("prediction_log.csv", "a", encoding="utf-8") as f:
            f.write(f"{datetime.now()},{skin_tone},{skin_type},{recommended},\"{full_review}\",{pred_rounded:.1f}\n")

        return render_template('index.html', 
                             prediction=pred_rounded,
                             emoji=emoji,
                             recommended=recommended,
                             raw_prediction=pred)

    return render_template('index.html')

@app.route('/batch', methods=['GET', 'POST'])
def batch():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file uploaded', 'error')
            return render_template('index.html')
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return render_template('index.html')

        if not file.filename.endswith('.csv'):
            flash('Please upload a CSV file', 'error')
            return render_template('index.html')

        try:
            # Read and process CSV
            df_batch = pd.read_csv(file)
            required_cols = {'review_title', 'review_text', 'skin_tone_grouped', 'skin_type'}
            
            if not required_cols.issubset(df_batch.columns):
                flash(f'CSV missing required columns: {required_cols}', 'error')
                return render_template('index.html')

            # Prepare data for prediction
            df_batch['full_review'] = df_batch['review_title'].fillna('') + " " + df_batch['review_text'].fillna('')
            df_batch['is_recommended'] = 'unknown'
            df_input = df_batch[['full_review', 'skin_tone_grouped', 'skin_type', 'is_recommended']]

            # Transform and predict
            X_input_transformed = preprocessor.transform(df_input)
            X_tensor = tf.convert_to_tensor(X_input_transformed.toarray(), dtype=tf.float32)
            preds = model.predict(X_tensor).flatten()
            preds_clipped = [round(max(1.0, min(5.0, p)) * 2) / 2 for p in preds]

            # Add predictions to dataframe
            df_batch['Predicted Rating'] = preds_clipped
            df_batch['Emoji'] = df_batch['Predicted Rating'].apply(rating_emoji)
            df_batch['Likely to Recommend'] = df_batch['Predicted Rating'].apply(lambda x: 'Yes' if x >= 3.0 else 'No')

            # Create CSV in memory
            output = io.StringIO()
            df_batch.to_csv(output, index=False)
            output.seek(0)

            return send_file(
                io.BytesIO(output.getvalue().encode('utf-8')),
                mimetype='text/csv',
                as_attachment=True,
                download_name='predicted_ratings.csv'
            )

        except Exception as e:
            flash(f'Error processing file: {str(e)}', 'error')
            return render_template('index.html')

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True) 